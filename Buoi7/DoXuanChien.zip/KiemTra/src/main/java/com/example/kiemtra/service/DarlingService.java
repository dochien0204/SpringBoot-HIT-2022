package com.example.kiemtra.service;


import com.example.kiemtra.dto.DarlingDTO;
import com.example.kiemtra.entity.Darling;
import org.apache.tomcat.jni.Address;

import java.util.List;

public interface DarlingService {
    List<Darling> findAllDarling();

    Darling findDarlingByStatus();

    Darling findDarlingAnnoy();

    Darling findDarlingById(Long id);

    void creatDarling(DarlingDTO darlingDTO);
    Darling updateDarling(Long id,DarlingDTO darlingDTO);

    void changeDarling(Long id);

}
