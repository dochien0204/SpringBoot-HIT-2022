package com.example.kiemtra.service;

import com.example.kiemtra.dto.AddressDTO;
import com.example.kiemtra.entity.Address;
import com.example.kiemtra.entity.Darling;
import com.example.kiemtra.repostitory.AddressRepository;
import com.example.kiemtra.repostitory.DarlingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class AddressServiceImpl implements AddressService{

    @Autowired
    private AddressRepository addressRepository;


    @Autowired
    private DarlingRepository darlingRepository;
    @Override
    public void createdAddress(Long id, AddressDTO addressDTO) {
        Address address = new Address();
        Darling darling = darlingRepository.findDarlingById(id);
        address.setName(addressDTO.getName());
        address.setCode(addressDTO.getCode());
        address.setDarling(darling);
        addressRepository.save(address);
    }

    @Override
    public List<Address> findAllAddress() {
        return addressRepository.findAll();
    }
}
