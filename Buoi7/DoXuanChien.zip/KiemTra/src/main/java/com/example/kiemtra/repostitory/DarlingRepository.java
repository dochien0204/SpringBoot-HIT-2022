package com.example.kiemtra.repostitory;

import com.example.kiemtra.entity.Darling;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface DarlingRepository  extends JpaRepository<Darling,Long> {
    Darling findDarlingByStatus(Integer status);
    Darling findDarlingById(Long id);

}
