package com.example.kiemtra.service;

import com.example.kiemtra.dto.DarlingDTO;
import com.example.kiemtra.entity.Address;
import com.example.kiemtra.entity.Darling;
import com.example.kiemtra.repostitory.DarlingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DarlingServiceImpl implements DarlingService {

    @Autowired
    private AddressService addressService;
    @Autowired
    private DarlingRepository darlingRepository;

    @Override
    public List<Darling> findAllDarling() {
        return darlingRepository.findAll();
    }

    @Override
    public Darling findDarlingByStatus() {
        Darling darling = darlingRepository.findDarlingByStatus(3);
        return darling;
    }

    @Override
    public Darling findDarlingAnnoy() {
        Darling darling = darlingRepository.findDarlingByStatus(2);
        return darling;
    }

    @Override
    public Darling findDarlingById(Long id) {
        return darlingRepository.findDarlingById(id);
    }

    @Override
    public void creatDarling(DarlingDTO darlingDTO) {
        Darling darling = new Darling();

        darling.setName(darlingDTO.getName());
        darling.setPhone(darlingDTO.getPhone());
        darling.setEmail(darlingDTO.getEmail());
        darling.setFavourite(darlingDTO.getFavourite());
        darling.setStatus(darlingDTO.getStatus());
        darlingRepository.save(darling);

    }

    @Override
    public Darling updateDarling(Long id,DarlingDTO darlingDTO) {
        Darling darling = darlingRepository.findDarlingById(id);
        darling.setName(darlingDTO.getName());
        darling.setPhone(darlingDTO.getPhone());
        darling.setEmail(darlingDTO.getEmail());
        darling.setFavourite(darlingDTO.getFavourite());
        darling.setStatus(darlingDTO.getStatus());
        darlingRepository.save(darling);
        return darling;
    }

    @Override
    public void changeDarling(Long id) {
        Darling darling = darlingRepository.findDarlingById(id);
        darling.setStatus(1);
        darlingRepository.save(darling);
    }
}
