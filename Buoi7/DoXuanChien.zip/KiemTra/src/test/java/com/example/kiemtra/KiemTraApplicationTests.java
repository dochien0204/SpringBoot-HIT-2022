package com.example.kiemtra;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KiemTraApplicationTests {

    @Test
    void contextLoads() {
    }

}
