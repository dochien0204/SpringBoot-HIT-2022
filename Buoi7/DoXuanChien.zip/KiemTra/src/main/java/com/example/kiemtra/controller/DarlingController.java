package com.example.kiemtra.controller;

import com.example.kiemtra.dto.DarlingDTO;
import com.example.kiemtra.service.DarlingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.swing.plaf.SpinnerUI;

@RestController
@RequestMapping("api/v1/darlings")
public class DarlingController {

    @Autowired
    private DarlingService darlingService;

    @GetMapping
    public ResponseEntity<?> findAllDarling()
    {
        return ResponseEntity.status(200).body(darlingService.findAllDarling());
    }

    @GetMapping
    @RequestMapping("/current")
    public ResponseEntity<?> findDarlingCurrent()
    {
        return ResponseEntity.status(200).body(darlingService.findDarlingByStatus());
    }

    @GetMapping("/annoy")
    public ResponseEntity<?> findDarlingAnnoy(@RequestParam(name = "status") Integer status)
    {
        return ResponseEntity.status(200).body(darlingService.findDarlingAnnoy());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> findDarlingById(@PathVariable("id") Long id)
    {
        return ResponseEntity.status(200).body(darlingService.findDarlingById(id));
    }

    @PostMapping
    public ResponseEntity<?> createDarling(@RequestBody DarlingDTO darlingDTO)
    {
        darlingService.creatDarling(darlingDTO);
        return ResponseEntity.status(200).body("Created sucessfull!");
    }

    @PatchMapping("/{id}")
    public ResponseEntity<?> updateDarling(@PathVariable("id") Long id,
                                           @RequestBody DarlingDTO darlingDTO)
    {
        darlingService.updateDarling(id,darlingDTO);
        return ResponseEntity.status(200).body("Update Darling Id = " + id +" sucessfull");
    }

    @PatchMapping("{/id}")
    public ResponseEntity<?> changeStatus(){
        darlingService.changeDarling();
        return ResponseEntity.status(200).body("Da thanh nguoi yeu cu");
    }
}
